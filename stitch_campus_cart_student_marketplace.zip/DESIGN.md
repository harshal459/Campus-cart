---
name: Campus Cart
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#414941'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#717970'
  outline-variant: '#c1c9be'
  surface-tint: '#396844'
  primary: '#023616'
  on-primary: '#ffffff'
  primary-container: '#1e4d2b'
  on-primary-container: '#8bbd92'
  inverse-primary: '#a0d3a6'
  secondary: '#326a38'
  on-secondary: '#ffffff'
  secondary-container: '#b1efb0'
  on-secondary-container: '#366e3c'
  tertiary: '#28302b'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e4641'
  on-tertiary-container: '#abb3ad'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bbefc1'
  primary-fixed-dim: '#a0d3a6'
  on-primary-fixed: '#00210b'
  on-primary-fixed-variant: '#21502e'
  secondary-fixed: '#b4f2b3'
  secondary-fixed-dim: '#98d599'
  on-secondary-fixed: '#002107'
  on-secondary-fixed-variant: '#185123'
  tertiary-fixed: '#dce4de'
  tertiary-fixed-dim: '#c0c8c2'
  on-tertiary-fixed: '#161d19'
  on-tertiary-fixed-variant: '#414944'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authentic, accessible, and grounded collegiate commerce experience. The target audience comprises university students, campus staff, and academic communities who demand speed, trust, and zero friction when buying, selling, or trading textbooks, dorm essentials, tech, and gear.

The visual direction merges **Clean Modernism** with an **Academic Collegiate Warmth**. Rather than feeling like a sterile corporate e-commerce platform or an ad-bloated local classifieds site, the interface evokes organized student life: crisp notebooks, campus greens, natural daylight, and structured clarity. It communicates safety, community accountability, and modern digital utility through thoughtful white space, tactile rounded cards, disciplined type hierarchy, and soft ambient contrast.

## Colors

The color palette centers around institutional trustworthiness, fresh campus surroundings, and warm utility.

- **Primary (`#1E4D2B`)**: Deep collegiate forest green anchors primary actions, key active states, brand headers, and critical interaction affordances. Its deeper shade (`#163E23`) serves hover states, pressed buttons, and high-emphasis focal points.
- **Secondary (`#4E8752`)**: A balanced sage leaf hue used for supporting indicators, interactive badges, success accents, and secondary button borders.
- **Tertiary (`#E8F0E9`)**: Soft sage wash providing a non-intrusive container tone for category pills, badge backdrops, user verification banners, and subtle callouts.
- **Neutral Surface & Canvas (`#F9FAF8`, `#F4F6F2`, `#FFFFFF`)**: Base canvases use warm ivory-tinted neutrals rather than cold synthetic grays. Cards and modals sit in crisp white (`#FFFFFF`) to achieve effortless separation over the off-white ground.
- **Typography & Borders (`#1F2937`, `#374151`, `#E5E7EB`)**: High-legibility dark slate typography delivers contrast without the harshness of pure black. Structural separation is maintained through thin hairline borders (`#E5E7EB`).

## Typography

Plus Jakarta Sans is utilized across all typographic levels. Its contemporary geometric underpinnings combined with warm, wide apertures mirror classic scholarly sans-serifs while delivering optimal screen legibility across dense product grids, chat interfaces, and pricing badges.

- **Headlines & Display**: Strong, confident, and tightly tracked to maintain punchiness without consuming disproportionate vertical space.
- **Body Text**: Generous vertical line-height ensures ease of reading for extended condition notes, textbook edition descriptions, and seller bios.
- **Labels & Microcopy**: Formatted with slightly increased tracking (`0.02em` to `0.03em`) and medium/semibold weight for rapid visual filtering of item tags, condition chips, and timestamp statuses.

## Layout & Spacing

The layout is grounded in a flexible 12-column responsive grid (desktop) shifting to 6 columns (tablet) and 2 or 4 columns (mobile):

- **Desktop (1024px+)**: Max-width container set to `1280px` with `2rem` margins and `1.25rem` gutters. Listings are displayed in 3- or 4-column configurations to maintain structural rhythm without crowding photos.
- **Tablet (768px - 1023px)**: 6 columns with `1.5rem` margins and `1rem` gutters. Product grids adapt to 2 or 3 columns.
- **Mobile (< 768px)**: 2-column asymmetric browsing grid or 1-column card stack with `1rem` margins and `0.75rem` gutters. Sticky bottom actions (such as "Message Seller" or "Make Offer") maintain safe-area padding.

All layout rhythms and internal container paddings adhere strictly to the 4px/8px modular scale defined by the spacing tokens.

## Elevation & Depth

This system utilizes gentle ambient shadows mixed with warm, low-contrast structural outlines rather than heavy skeuomorphic drops.

- **Base Surface (`Level 0`)**: `#F9FAF8` ground with zero shadow.
- **Cards & Containers (`Level 1`)**: `#FFFFFF` background coupled with a 1px border of `#E5E7EB` and an ultra-soft ambient shadow (`0 2px 8px -2px rgba(30, 77, 43, 0.05), 0 1px 3px 0 rgba(0, 0, 0, 0.03)`). The soft green tint in the shadow anchors the surface organically into the collegiate palette.
- **Interactive Hover & Flyouts (`Level 2`)**: Used when a student hovers over an item card or opens an action popover (`0 10px 20px -3px rgba(30, 77, 43, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)`). The card subtly translates upward by 2px.
- **Modals, Drawers & Bottom Sheets (`Level 3`)**: Overlays for fast negotiations, checkout, or photo inspection (`0 20px 30px -6px rgba(22, 62, 35, 0.14), 0 8px 10px -4px rgba(0, 0, 0, 0.06)`), complemented by a `rgba(31, 41, 55, 0.45)` backdrop blur.

## Shapes

The interface embraces friendly, approachable geometry. Standard interactive elements employ `0.5rem` (`8px`) corner radius, creating clear click boundaries. 

Cards and modal containers adopt generous `rounded-xl` (`1.5rem` / `24px`) radii to instill an informal, approachable feel suitable for student exchanges. Pill-shaped geometry (`9999px`) is reserved exclusively for status badges, filter chips, category shortcuts, and floating action prompts.

## Components

### Buttons
- **Primary**: Solid `#1E4D2B` fill with `#FFFFFF` text. Height of 44px (touch target compliant), `rounded-lg` (12px), bold label. Hover transforms to `#163E23`.
- **Secondary**: `#E8F0E9` background with `#1E4D2B` text. On hover, background shifts to a deeper sage tone (`#DAE7DC`).
- **Outline**: 1.5px border in `#1E4D2B` or `#E5E7EB` with dark slate text `#1F2937`, white background, transitioning to `#F4F6F2` on hover.

### Chips & Category Pills
- Filter and taxonomy chips are fully pill-shaped (`rounded-full`) with a height of 36px.
- **Inactive**: `#FFFFFF` ground, `#E5E7EB` 1px border, `#374151` text.
- **Active**: `#1E4D2B` ground, `#FFFFFF` text, shadow-sm.
- **Quick Tags / Condition Tags**: Compact pill with `#E8F0E9` background and `#1E4D2B` label (e.g., "Like New", "BIO 101", "Dorm Pickup").

### Marketplace Product Cards
- Contained within `rounded-xl` borders featuring `#FFFFFF` background, 1px `#E5E7EB` stroke, and Level 1 elevation.
- Product photography maintains a consistent 4:3 or 1:1 aspect ratio with `rounded-t-xl` corners.
- Internal body includes: price rendered in `headline-sm` (`#1E4D2B`), title in `title-sm` (`#1F2937`), building or dorm meetup indicator with a micro pin icon, and a relative post timestamp (`#6B7280`).

### Input Fields & Search Bars
- Global search bar is large (48px height) with a pill or `rounded-xl` structure, subtle `#E5E7EB` border, search icon prefix in `#4E8752`, and `#F9FAF8` interior fill, focusing to `#FFFFFF` with a 2px `#1E4D2B` ring.
- Form inputs feature clear floating labels, assistive hint text in `body-sm`, and explicit error states with gentle red tinting (`#DC2626`).

### Checkboxes & Radio Buttons
- 20px controls with a 2px stroke in `#D1D5DB`. When checked, the fill transitions smoothly to `#1E4D2B` displaying a crisp white indicator. Radio buttons utilize an internal circular dot with 4px white inset spacing.

### Student Verification Badge
- Custom micro-component displaying `.edu Verified` with an academic cap glyph. Features an `#E8F0E9` background, `#1E4D2B` text, 1px `#C3D7C5` border, and pill geometry to reinforce peer safety throughout message threads and seller bios.